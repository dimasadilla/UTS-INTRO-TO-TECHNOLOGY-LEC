ini adalah project UTS INTRO TO TECHNOLOGY dari Kelompok Bersaudara yang berisi dari 4 orang yaitu : 
1. Oki Rahmat (00000075792) 
2. jessen Valensio (00000076210)
3. Naufal Fawwaz (00000075866)  
4. Leonardus Dwiky Dimas Arya Adilla (00000075794)