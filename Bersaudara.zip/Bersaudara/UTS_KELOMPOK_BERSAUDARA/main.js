function gantiKarakter(gambar) {
    var karakter = document.getElementById("karakter");
    karakter.style.backgroundImage = "url('" + gambar + "')";
}